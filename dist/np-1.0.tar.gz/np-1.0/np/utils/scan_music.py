import subprocess
import os
from np import readConf, test_db, addtodb, log
from np.utils.tadb_search import lookup
from np.utils.id3 import tag
id3 = tag()

def scan_music(target_dir=None):
	test_db()
	conf = readConf()
	if target_dir == None:
		target_dir = conf['media_directories']['music']
	com = ("find '" + target_dir + "' -name '*.mp3'")
	files = subprocess.check_output(com, shell=True).decode().strip()
	files = files.split("\n")
	needs_tagged = []
	ct = len(files)
	pos = 0
	for filepath in files:
		pos = pos + 1
		hastag = True
		tag_data = {}
		title = None
		artist = None
		txt = ("Progress: (" + str(pos) + "/" + str(ct) + ", filepath:" + filepath)
		audiofile = None
		print (txt)
		if filepath == '' or not os.path.exists(filepath):
			log("Error: No file path provided (directory might be empty?)", 'info')
			break
		tag = id3.read(filepath)
		try:
			title = tag.title
			artist = tag.artist
			hastag = True
		except:
			title = None
			artist = None
			hastag = False

		if tag.title is None or tag.artist is None or hastag == False:
			split = (f"{target_dir}/")
			fname = filepath.split(split)[1]
			if '[' in fname:
				if tag.title is None:
					tag.title = fname.split('[')[0].strip()
				if tag.artist is None:
					s = ' - '
					tag.artist = fname.split(s)[1].split('.')[0]
			else:
				s = ' - '
				try:
					if tag.title is None:
						tag.title = fname.split(s)[0]
					if tag.artist is None:
						tag.artist = fname.split(s)[1].split('.')[0]
				except:
					print (f"File: '{filepath}' - Unable to parse info from path.")
					tag.title = input("Enter artist name: ")
					tag.artist = input("Enter song title: ")
		info = lookup(tag.artist, tag.title)

		if info['artist'] != 'Unknown':
			tag.artist = info['artist']
		else:
			if tag.artist == None:
				tag.artist = input("Enter artist:")
		if info['album'] != 'Unknown':
			tag.album = info['album']
		else:
			if tag.album == None:
				tag.artist = input("Enter artist:")
		if info['track'] != 'Unknown':
			tag.track = info['track']
		else:
			track = 0
		if info['album_id'] != "Unknown":
			tag.album_id = info['album_id']
		if info['artist_id'] != "Unknown":
			tag.artist_id = info['artist_id']
		if info['genre'] != "Unknown":
			tag.genre = info['genre']
		if info['mbid'] != "Unknown":
			tag.mbid = info['mbid']
		tag.save(filepath)
		isactive = info['isactive']
		title = info['title']
		mbid = info['mbid']
		album = info['album']
		album_id = info['album_id']
		artist_id = info['artist_id']
		artist = info['artist']
		genre = info['genre']
		track = info['track']

		sql_string = (f"INSERT INTO music (isactive, title, mbid, album, album_id, artist_id, artist, genre, track, filepath) VALUES({isactive}, '{title}', '{mbid}', '{album}', '{album_id}', '{artist_id}', '{artist}', '{genre}', {track}, '{filepath}');")
		ret = addtodb('music', sql_string)
		if ret is not True:
			print (ret)

if __name__ == "__main__":
	ret = scan_music()
	print (ret)
