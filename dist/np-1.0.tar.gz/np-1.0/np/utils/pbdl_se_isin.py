#!/usr/bin/env python3

def mk_list():
	_list = []
	for s in range(0, 99):
		for e in range(0, 99):
			if len(str(s)) == 1:
				season = f"0{s}"
			else:
				season = str(s)
			if len(str(e)) == 1:
				ep = f"0{e}"
			else:
				ep = str(e)
			_list.append(f"S{season}E{ep}")
			_list.append(f"S{season}e{ep}")
			_list.append(f"s{season}E{ep}")
			_list.append(f"s{season}e{ep}")
	return _list

def parse(filepath):
	_list = mk_list()
	out = []
	for item in _list:
		if item in filepath:
			return item
	return None


def se_isin(filepath):
	string = parse(filepath)
	s = None
	e = None
	if string is not None:
		string = string.upper()
		s = string.split('S')[1].split('E')[0]
		e = string.split('E')[1]
		if '0' in s:
			d0 = s[:1]
			d1 = s[1:]
			if d0 == '0':
				s = d1
			else:
				s = (f"{d0}{d1}")
		if '0' in e:
			d0 = e[:1]
			d1 = e[1:]
			if d0 == '0':
				e = d1
			else:
				e = (f"{d0}{d1}")
	return (s,e)


if __name__ == "__main__":
	import sys
	try:
		filepath = sys.argv[1]
	except:
		print ("No filepath provided!")
	ret = se_isin(filepath)
	print (ret)
