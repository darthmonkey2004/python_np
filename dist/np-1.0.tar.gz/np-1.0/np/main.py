#!/usr/bin/env python3

from np import np
np.start()
